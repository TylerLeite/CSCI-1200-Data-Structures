HOMEWORK 4: PREFERENCE LISTS


NAME: Tyler Leite


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.


Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT: 2.5 hrs



ORDER NOTATION:


add_school: num_prefs+num_schools

insert_student_into_school_preference_list: num_students+size_pref_list

print_school_preferences: num_schools+size_pref_list

add_student: num_prefs+num_schools

remove_school_from_student_preference_list: num_students+size_pref_list

print_student_preferences: num_students+size_pref_list

perform_matching:

print_school_enrollments: num_schools*max_enrollments

print_student_decisions: num_students



MISC. COMMENTS TO GRADER:  
Optional, please be concise!


