#ifndef SOLUTION_H
#define SOLUTION_H

#include <algorithm>
#include <vector>

#define NORTH 0
#define EAST  1
#define SOUTH 2
#define WEST  3

bool fits_with(const Tile& t1, const Tile& t2, int side){
    //if (t1 == NULL || t2 == NULL) return true;
    if (side == NORTH) return t1.getNorth() == t2.getSouth();
    if (side == EAST)  return t1.getEast() == t2.getWest();
    if (side == SOUTH) return t1.getSouth() == t2.getNorth();
    if (side == WEST)  return t1.getWest() == t2.getEast();
}

int opposite_of(int side){
    if (side == NORTH) return SOUTH;
    if (side == EAST)  return WEST;
    if (side == SOUTH) return NORTH;
    if (side == WEST)  return EAST;
}

Location get_loc_neighbor(int direction, const Location& loc){
    int yOff = 0, xOff = 0; //offsets based on direction

    if      (direction == NORTH) yOff = -1;
    else if (direction == EAST)  xOff =  1;
    else if (direction == SOUTH) yOff =  1;
    else if (direction == WEST)  xOff = -1;

    Location new_loc(loc.column+xOff, loc.row+yOff, 0);
    return new_loc;
}

Tile get_neighbor(int direction, const Location& loc, const std::vector<Tile>& possibleNeighbors, bool& neighborExists){
    Location test_loc = get_loc_neighbor(direction, loc);

    neighborExists = false;
    for (int i = 0; i < possibleNeighbors.size(); i++){
        if (possibleNeighbors[i].loc == test_loc){
            neighborExists = true;
            return possibleNeighbors[i];
        }
    }

    return possibleNeighbors[0]; //no neighbor to that side, always check neighborExists
}

//NOTE: unplacedTiles must be reversed before being passed to this function for the first time
//do locations relatively, start at 0,0 and dont mind when it goes negative
// then shift everything until it is all positive. if a placement woudld go out
// of bounds, leave it in and test them later to get rid of them.
std::vector<std::vector<Tile> > place_tiles(std::vector<Tile> unplacedTiles, bool allowRotations=false){//dont want to pass by reference
    std::vector<std::vector<Tile> > out;

    if (unplacedTiles.size() == 0){
        return out;
    } else if (unplacedTiles.size() == 1){
        unplacedTiles[0].loc = Location(0,0,0);
        out.push_back(unplacedTiles);
        return out;
    } else {
        Tile to_place = unplacedTiles[0];
        unplacedTiles.erase(unplacedTiles.begin());

        std::vector<std::vector<Tile> > soFar = place_tiles(unplacedTiles, allowRotations);

      //why can't i hold all these for loops?
      //todo: replace all for lloops with recursion because why not
        for (int p = 0; p < soFar.size(); p++){ //loop through all placement options so far
            std::vector<Location> locationsTried; //avoid redundancy in the case of placing a tile between two tiles
            for (int t = 0; t < soFar[p].size(); t++){ //loop through tiles in that placement
                for (int s = 0; s < 4; s++){ //loop through each side the tile could be placed on
                    int rotations = 1;
                    if (allowRotations){
                        rotations = 4;
                    }
                    
                    //get location the tile would be placed at
                    Location new_loc = get_loc_neighbor(s, soFar[p][t].loc);
                    
                    for (int d = 0; d < rotations; d++){
                        //update location's rotation
                        new_loc.rotation = d*90;
                        to_place.loc = new_loc;

                        //check if that location was tried yet
                        if (std::find(locationsTried.begin(), locationsTried.end(), new_loc) == locationsTried.end()){
                            //check if that location fits with all neighbors
                            bool works = true;
                            for (int n = 0; n < 4; n++){
                                bool neighborExists;
                                Tile surrounding = get_neighbor(n, to_place.loc, soFar[p], neighborExists);
                                if (neighborExists && fits_with(to_place, surrounding, n)){
                                    //add path to output that is current path plus to_place
                                    std::vector<Tile> to_out = soFar[p];
                                    to_out.push_back(to_place);
                                    out.push_back(to_out);
                                }
                            }
                        }
                    }
                }
            }
        }

        return out;
    }
}

#endif
