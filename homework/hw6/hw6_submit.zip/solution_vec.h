#ifndef SOLUTION_H
#define SOLUTION_H

#include <algorithm>
#include <vector>

#define NORTH 0
#define EAST  1
#define SOUTH 2
#define WEST  3

bool fits_with(const Tile* t1, const Tile* t2, int side){
    if (t1 == NULL || t2 == NULL) return true;
/*
    if (side == NORTH)
        std::cout << t1->getNorth() << ":" << t2->getSouth() << std::endl;
    else if (side == EAST)
        std::cout << t1->getEast() << ":" << t2->getWest() << std::endl;
    else if (side == SOUTH)
        std::cout << t1->getSouth() << ":" << t2->getNorth() << std::endl;
    else if (side == WEST)
        std::cout << t1->getWest() << ":" << t2->getEast() << std::endl;
    else
        std::cout << "oh, no! something has gone horribly wrong!" << std::endl;
*/
    if (side == NORTH) return t1->getNorth() == t2->getSouth();
    if (side == EAST)  return t1->getEast() == t2->getWest();
    if (side == SOUTH) return t1->getSouth() == t2->getNorth();
    if (side == WEST)  return t1->getWest() == t2->getEast();
}

int opposite_of(int side){
    if (side == NORTH) return SOUTH;
    if (side == EAST)  return WEST;
    if (side == SOUTH) return NORTH;
    if (side == WEST)  return EAST;
}

Location get_loc_neighbor(int direction, const Location& loc){
    int yOff = 0, xOff = 0; //offsets based on direction

    if      (direction == NORTH) yOff = -1;
    else if (direction == EAST)  xOff =  1;
    else if (direction == SOUTH) yOff =  1;
    else if (direction == WEST)  xOff = -1;

    Location newLoc(loc.row+yOff, loc.column+xOff, 0); //todo: fix for rotations
    return newLoc;
}

Tile* get_neighbor(int direction, const Location& loc, const std::vector<Tile*>& possibleNeighbors){
    Location test_loc = get_loc_neighbor(direction, loc);
    
    for (std::vector<Tile*>::iterator it = possibleNeighbors.begin(); it != possibleNeighbors.end(); it++){
        if (it->loc == test_loc){
            return *it;
        }
    }

    return NULL; //no neighbor to that side
}


//check if a piece works
bool piece_fits (Tile* toPlace, const std::vector<Tile*>& possibleNeighbors){
    bool works = true;
    for (int i = 0; i < 4; i++){//check if that location is a legal placement
        Tile* surrounding = get_neighbor(i, toPlace->loc, possibleNeighbors);
        if (!fits_with(toPlace, surrounding, i)){
            works = false;
            break;
        }
    }

    return works;
}


bool solution_viable(std::vector<Tile*>& toOut, int boardWdt, int boardHgt){
    //check if pieces go out of bounds
    int minX = 1000, minY = 1000, maxX = -1000, maxY = -1000;
    for (std::vector<Tile*>::iterator it = toOut.begin(); it != toOut.end(); it++){
        if (toOut[i]->loc.column < minX){
            minX = it->loc.column;
        }

        if (toOut[i]->loc.column > maxX){
            maxX = it->loc.column;
        }

        if (toOut[i]->loc.row < minY){
            minY = it->loc.row;
        }

        if (toOut[i]->loc.row > maxY){
            maxY = it->loc.row;
        }
    }

    if (maxX-minX <= boardWdt && maxY-minY <= boardHgt){
        return true;
    } else {
        return false;
    }
}

//TODO: fix allowing rotations and all solutions

//NOTE: unplacedTiles must be reversed before being passed to this function for the first time
//do locations relatively, start at 0,0 and dont mind when it goes negative
// then shift everything until it is all positive. if a placement woudld go out
// of bounds, leave it in and test them later to get rid of them.
std::vector<std::vector<Tile*> > place_tiles(std::vector<Tile*> unplacedTiles, int boardWdt, int boardHgt, bool allowRotations){//dont want to pass by reference
    std::vector<std::vector<Tile*> > out;
    if (unplacedTiles.size() == 0){
        std::cout << "0" << std::endl;
        return out;
    } else if (unplacedTiles.size() == 1){
        unplacedTiles[0]->loc = Location(0,0,0);
        out.push_back(unplacedTiles);
        std::cout << "1" << std::endl;
        return out;
    } else {
        Tile* toPlace = unplacedTiles[0];
        unplacedTiles.erase(unplacedTiles.begin());

        std::vector<std::vector<Tile*> > soFar = place_tiles(unplacedTiles, boardWdt, boardHgt, allowRotations);

      //why can't i hold all these for loops?
      //todo: replace all for loops with recursion because why not
        for (int p = 0; p < soFar.size(); p++){ //loop through all placement options so far
            std::vector<Location> locationsTried; //avoid redundancy in the case of placing a tile between two tiles
            for (int t = 0; t < soFar[p].size(); t++){ //loop through tiles in that placement
                for (int s = 0; s < 4; s++){ //loop through each side the tile could be placed on
                    if (get_neighbor(s, soFar[p][t]->loc, soFar[p]) != NULL){continue;} //check if there is already a tile there
                    Location newLoc = get_loc_neighbor(s, soFar[p][t]->loc); //get location the tile would be placed at

                    bool already = false; //was this location already tried
                    for (int i = 0; i < locationsTried.size(); i++){//check if that location was tried yet
                        if (locationsTried[i] == newLoc){
                            already = true;
                        }
                    }
                    if (already) continue;
                    
                    locationsTried.push_back(newLoc);
                    //std::cout << "p: " << p << ", t: " << t << ", loc: " << newLoc << std::endl;

                    int rotations = 1; if (allowRotations) rotations = 4;

                    for (int d = 0; d < rotations; d++){//loop through all rotation
                        //std::cout << "Moving to rotation: " << d << std::endl;
                        newLoc.rotation = d*90;
                        Tile* realToPlace = new Tile(toPlace->getNorth(), toPlace->getEast(), toPlace->getSouth(), toPlace->getWest());
                        realToPlace->loc = newLoc;

                        if (!piece_fits(realToPlace, soFar[p])){delete realToPlace; continue;}
                        
                        //add path to output that is current path plus toPlace
                        std::vector<Tile*> toOut;
                        for (int i = 0; i < soFar[p].size(); i++){
                            Tile* new_tile = new Tile(soFar[p][i]->getNorth(), soFar[p][i]->getEast(), soFar[p][i]->getSouth(), soFar[p][i]->getWest());
                            new_tile->loc = soFar[p][i]->loc;
                            toOut.push_back(new_tile);
                        }
                        
                        toOut.push_back(realToPlace);

                        if (solution_viable(toOut, boardWdt, boardHgt)){//check if pieces go out of bounds
                            //std::cout << newLoc << std::endl;
                            out.push_back(toOut);
                        } else {
                            for (int i = 0; i < toOut.size(); i++){
                                delete toOut[i];
                            }
                        }
                    }
                }
            }
        }

        std::cout << "got to end: " << out.size() << std::endl;
        return out;
    }
}

std::vector<std::vector<Tile*> > solve(std::vector<Tile*>& unplacedTiles, int boardWdt, int boardHgt, bool allowRotations){
    std::reverse(unplacedTiles.begin(), unplacedTiles.end());

    std::vector<std::vector<Tile*> > solutions;
    solutions = place_tiles(unplacedTiles, boardWdt, boardHgt, allowRotations);

    //make everything positive
    for (int i = 0; i < solutions.size(); i++){
        int minX = 1000, minY = 1000, maxX = -1000, maxY = -1000;
        for (int j = 0; j < solutions[i].size(); j++){
            if (solutions[i][j]->loc.column < minX){
                minX = solutions[i][j]->loc.column;
            } else if (solutions[i][j]->loc.column > maxX){
                maxX = solutions[i][j]->loc.column;
            }

            if (solutions[i][j]->loc.row < minY){
                minY = solutions[i][j]->loc.row;
            } else if (solutions[i][j]->loc.row > maxY){
                maxY = solutions[i][j]->loc.row;
            }
        }

        for (int j = 0; j < solutions[i].size(); j++){
            if (minX < 0){
                solutions[i][j]->loc.column += -minX;
            }

            if (minY < 0){
                solutions[i][j]->loc.row += -minY;
            }
        }
    }

    return solutions;
}

#endif
