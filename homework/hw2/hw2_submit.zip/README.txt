HOMEWORK 2: BOWLING CLASSES


NAME:  Tyler Leite


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

www.cplusplus.com/reference/

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  4hrs 30 mins



DESCRIPTION OF YOUR CREATIVE STATISTIC:
Please be concise!

Average, best, and worst strike rate: how frequently the bowlers score strikes
(on throws where they have a chance for it). Spares where the first throw was 0
are not counted as strikes

